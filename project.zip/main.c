#include <stdio.h>
#include "parse.h"

int main(int argc, char* argv[])
{
	parse(argv[1]);
	
}
