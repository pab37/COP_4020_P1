#ifndef SYMBOL_H
#define SYMBOL_H
#include "lexer.h"


struct entry symTable[1000];
//char expression[500];

#endif